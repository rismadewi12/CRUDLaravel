

<?php $__env->startSection('title','About'); ?>

<?php $__env->startSection('container'); ?>

     <div class="container">
        <div class="row">
            <div class="col-10">
            <h1 class="mt-2">Hello,<?php echo e($nama); ?></h1>
            <img src="<?php echo e(asset('template')); ?>/dist/img/imoo.jpeg" width="250px">
            </div>
        </div>
     </div>

<?php $__env->stopSection(); ?>
    
    

<?php echo $__env->make('layout/utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/about.blade.php ENDPATH**/ ?>