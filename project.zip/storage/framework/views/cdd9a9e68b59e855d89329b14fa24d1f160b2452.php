

<?php $__env->startSection('title','Detail Mahasiswa'); ?>

<?php $__env->startSection('container'); ?>

     <div class="container">
        <div class="row">
            <div class="col-8">
            <h1 class="mt-2">Detail Mahasiswa</h1>
            <div class="card">
            <ul class="list-group list-group-flush">
                <div class="card-body">
                    <h5 class="list-group-item"><?php echo e($student->Nama); ?></h5>
                    <h6 class="list-group-item"><?php echo e($student->Nim); ?></h6>
                    <p class="list-group-item"><?php echo e($student->Kelas); ?></p>
                    <p class="list-group-item"><?php echo e($student->Skor); ?></p>

                    <a href="/students/<?php echo e($student->id); ?>/edit" class="btn btn-primary">Edit</a>

                    <form action="/students/ <?php echo e($student->id); ?>" method="post" class="d-inline">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                    </form> 
                    <a href="/students" class="card-link"> Back</a>
                </div>
            </ul>    
            </div>
        </div>
     </div>

<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout/utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/students/show.blade.php ENDPATH**/ ?>