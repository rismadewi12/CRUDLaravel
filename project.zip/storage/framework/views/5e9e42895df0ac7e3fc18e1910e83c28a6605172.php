

<?php $__env->startSection('title','Statistika Risma'); ?>

<?php $__env->startSection('container'); ?>

     <div class="container">
        <div class="row">
            <div class="col-10">
            <h1 class="mt-2"><b>TEKNIK INFORMATIKA<b></h1>
            <h1 class="mt-2"><b>FAKULTAS TEKNIK DAN KEJURUAN<b></h1>
            <img src="<?php echo e(asset('template')); ?>/dist/img/12.jpg">
            </div>
        </div>
     </div>

<?php $__env->stopSection(); ?>
    
    

<?php echo $__env->make('layout/utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/index.blade.php ENDPATH**/ ?>