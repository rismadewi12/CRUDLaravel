

<?php $__env->startSection('title',); ?>

<?php $__env->startSection('container'); ?>

     <div class="container">
        <div class="row">
            <div class="col-8">
            <h1 >Data Mahasiswa</h1>

                <a href="/students/create" class="btn btn-primary" my=3 >Tambah Data Mahasiswa</a>
                <p1 > Note : Untuk Mengubah Data Mahasiswa silahkan mengklik tombol Detail</p1>
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <ul class="list-group">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?php echo e($student->Nama); ?>

                        <a href="/students/show/<?php echo e($student->id); ?>" class="badge badge-info">Detail</a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
        </div>
     </div>

<?php $__env->stopSection(); ?>
    
<?php echo $__env->make('layout/utama', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\project\resources\views/students/index.blade.php ENDPATH**/ ?>