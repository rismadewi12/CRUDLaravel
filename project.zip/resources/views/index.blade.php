@extends('layout/utama')

@section('title','Statistika Risma')

@section('container')

     <div class="container">
        <div class="row">
            <div class="col-10">
            <h1 class="mt-2"><b>TEKNIK INFORMATIKA<b></h1>
            <h1 class="mt-2"><b>FAKULTAS TEKNIK DAN KEJURUAN<b></h1>
            <img src="{{asset('template')}}/dist/img/12.jpg">
            </div>
        </div>
     </div>

@endsection
    
    
