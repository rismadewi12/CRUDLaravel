@extends('layout/utama')

@section('title','Detail Mahasiswa')

@section('container')

     <div class="container">
        <div class="row">
            <div class="col-8">
            <h1 class="mt-2">Detail Mahasiswa</h1>
            <div class="card">
            <ul class="list-group list-group-flush">
                <div class="card-body">
                    <h5 class="list-group-item">{{ $student->Nama }}</h5>
                    <h6 class="list-group-item">{{ $student->Nim }}</h6>
                    <p class="list-group-item">{{ $student->Kelas }}</p>
                    <p class="list-group-item">{{ $student->Skor }}</p>

                    <a href="/students/{{ $student->id }}/edit" class="btn btn-primary">Edit</a>

                    <form action="/students/ {{$student->id}}" method="post" class="d-inline">
                            @method('delete')
                            @csrf
                            <button type="submit" class="btn btn-danger">Delete</button>
                    </form> 
                    <a href="/students" class="card-link"> Back</a>
                </div>
            </ul>    
            </div>
        </div>
     </div>

@endsection
    