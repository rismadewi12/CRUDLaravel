@extends('layout/utama')

@section('title',)

@section('container')

     <div class="container">
        <div class="row">
            <div class="col-8">
            <h1 >Data Mahasiswa</h1>

                <a href="/students/create" class="btn btn-primary" my=3 >Tambah Data Mahasiswa</a>
                <p1 > Note : Untuk Mengubah Data Mahasiswa silahkan mengklik tombol Detail</p1>
                @if (session('status'))
                    <div class="alert alert-success">
                        {{ session('status')}}
                    </div>
                @endif

                <ul class="list-group">
                @foreach( $students as $student )
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        {{ $student->Nama }}
                        <a href="/students/show/{{ $student->id }}" class="badge badge-info">Detail</a>
                    </li>
                    @endforeach
                </ul>

            </div>
        </div>
     </div>

@endsection
    